#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h> 
#include <stdatomic.h> 

//pthread_create (&opisnik, NULL, funkcija, &podaci)
// -pthread kod compileanja!!!
int M;
int A;
int N;
atomic_int *ulaz, *broj;

void LKO(int i) {
    printf("Dretva %d ulazi u LKO funkciju", i);
    ulaz[i] = 1;
    atomic_int max = broj[0];
    for(int j = 1; j < N; j++) {
        if(broj[j]>max) max = broj[j];
    }
    broj[i] = max + 1; 
    ulaz[i] = 0;
    printf("Dretva %d postavila max", i);
    for(int j = 0; j < N; j++) {
        while(ulaz[j]!= 0);
        while(broj[j] != 0 && (broj[j] < broj[i] || (broj[j] == broj[i] && j<i)));
    }
    printf("Dretva %d izlazi iz LKO funkcije", i);
    sleep(0.00001);
}

void LNKO(int i) {
    broj[i] = 0;
}

void *posao_dretve(void *arg) {
    int temp = *((int *) arg); 
    int i = 0;
    while(i<M) {
        LKO(temp);
        A++;
        LNKO(temp);
        i++;
    }
    printf("Gotovo\n");
    return NULL;
}

int main() {
    pthread_t* dretve; //velicine N

    printf("Upisi N: ");
    scanf("%d", &N);
    printf("Upisi M: ");
    scanf("%d", &M);

    dretve = malloc(N*sizeof(int));
    ulaz = malloc(N*sizeof(atomic_int));
    broj = malloc(N*sizeof(atomic_int));

    int idx[N];

    for(int i = 0; i < N; i++) {
        ulaz[i] = 0;
        broj[i] = 0;
        idx[i] = i;
    }

    for (int i = 0; i < N; i++) {
        printf("Stvaranje dretve %d\n",i);
        pthread_create(&dretve[i],NULL,posao_dretve,&idx[i]); 
    }

    //sleep(1);

    printf("Roditelj ceka\n");
    for(int i = 0; i < N; i++) {  
        printf("Cekam kraj dretve %d\n",i);
        pthread_join(dretve[i],NULL); //ako iz posao_dretve vracamo nesto, nece ici NULL
        printf("Gotova dretva...\n");
    }
    printf("%d\n", A);

    return 0;
}