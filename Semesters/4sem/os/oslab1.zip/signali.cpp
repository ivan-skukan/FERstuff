#include <iostream>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <errno.h>
#include <time.h>
#include <string>
#include <cstring>
using namespace std;

struct timespec t0;
int t_p = 0;
int k_z[3];
string stog[4] = {"","","",""};
bool promjenaTP=false;

void postavi_pocetno_vrijeme()
{
	clock_gettime(CLOCK_REALTIME, &t0);
}

void vrijeme(void)
{
	struct timespec t;

	clock_gettime(CLOCK_REALTIME, &t);

	t.tv_sec -= t0.tv_sec;
	t.tv_nsec -= t0.tv_nsec;
	if (t.tv_nsec < 0) {
		t.tv_nsec += 1000000000;
		t.tv_sec--;
	}

	printf("%03ld.%03ld:\t", t.tv_sec, t.tv_nsec/1000000);
}

#define PRINTF(format, ...)       \
do {                              \
  vrijeme();                      \
  printf(format, ##__VA_ARGS__);  \
}                                 \
while(0)

void spavaj(time_t sekundi)
{
	struct timespec koliko;
	koliko.tv_sec = sekundi;
	koliko.tv_nsec = 0;

	while (nanosleep(&koliko, &koliko) == -1 && errno == EINTR)
		PRINTF("Bio prekinut, nastavljam\n");
}

void obradi_sig(int sig);

void printajstatus() {

    string stogSadrzaj = "";
    for(int i = 0; i < 3; i++) {
        if(stog[i] != "") {
            stogSadrzaj =  stogSadrzaj + stog[i] + ";";
        } else {
            break;
        }
    }

    char s0[stog[0].length()+1],s1[stog[1].length()+1],s2[stog[2].length()+1];

    strcpy(s0,stog[0].c_str());
    strcpy(s1,stog[1].c_str());
    strcpy(s2,stog[2].c_str());

    PRINTF("K_Z: %d%d%d; T_P: %d stog: %s;%s;%s;\n", k_z[0],k_z[1],k_z[2],t_p,s0,s1,s2);  //dovrsi
}

void pushStog(int naStog) {

    for(int i = 2; i>=1; i--) {
        stog[i] = stog[i-1];
    }

    switch(naStog) {
        case 0: stog[0] = "0,r[0]";
                break;
        case 1: stog[0] = "1,r[1]";
                break;
        case 2: stog[0] = "2,r[2]";
                break;                
    }
}

string popStog() { 

    string ret = stog[0];

    for(int i = 0; i < 3; i++) {
        stog[i] = stog[i+1];
    }

    return ret;
}

void inicijalizacija()
{
	struct sigaction act;

	/* 1. maskiranje signala SIGUSR1 */

	/* kojom se funkcijom signal obradjuje */
	act.sa_handler = obradi_sig;

	/* koje jos signale treba blokirati dok se signal obradjuje */
	sigemptyset(&act.sa_mask);
	//sigaddset(&act.sa_mask, SIGTERM); <-zasto je ovo tu??

	act.sa_flags = SA_NODEFER; //VAZNO!!!!

	/* maskiranje signala - povezivanje sucelja OS-a */
	sigaction(SIGUSR1, &act, NULL);

	/* 2. maskiranje signala SIGTERM */
	act.sa_handler = obradi_sig;
	sigemptyset(&act.sa_mask);
	sigaction(SIGTERM, &act, NULL);

	/* 3. maskiranje signala SIGINT */
	act.sa_handler = obradi_sig;
	sigaction(SIGINT, &act, NULL);

	postavi_pocetno_vrijeme();
}

int main() {

    inicijalizacija();

    PRINTF("Program s PID=%d krenuo s radom\n", getpid());
    printajstatus();
    
    while(1) {sleep(1);};

    return 0;
}


//sigterm>sigint>sigusr

void obradi_sig(int sig) {
	
	int prioritetSignala;
	if(sig == 10) prioritetSignala = 1;
	if(sig == 2) prioritetSignala = 2;
	if(sig == 15) prioritetSignala = 3;

    k_z[prioritetSignala-1] = 1;

    int naStog;
    int check;
    string saStoga;

	if((prioritetSignala>t_p)) {

        naStog=t_p;

        if(promjenaTP) PRINTF("SKLOP:promjenio se TP, obrađuje se %d\n", prioritetSignala);
        else PRINTF("SKLOP: Prekid razine %d, prosljeđuje se procesoru\n",prioritetSignala);


        switch(prioritetSignala) {

            case 1:
                    printajstatus();
                    printf("\n");

    	            t_p = prioritetSignala;
                    PRINTF("Počela obrada prekida razine %d\n", t_p);
                    k_z[t_p-1] = 0;

                    pushStog(naStog);
                    printajstatus();
                    printf("\n");

                    //dozvola prekida?

                    for(int i = 1; i<=8; i++) {
                        sleep(1);
                    }
                    PRINTF("Završila obrada prekida razine 1\n");

                    saStoga = popStog().substr(0,1);
                    check = stoi(saStoga); 
                    t_p = check;

                    if(check == 0) {

                        PRINTF("Nastavlja se glavni program\n");
                    } else {
                        PRINTF("Nastavlje se prekid %d\n\n", check);
                    }
                    printajstatus();
                    printf("\n");

                    break;

            case 2: 
                    printajstatus();
                    printf("\n");

                    t_p = prioritetSignala;
                    PRINTF("Počela obrada prekida razine %d\n", t_p);
                    k_z[t_p-1] = 0;

                    pushStog(naStog); //provjeri
                    printajstatus();
                    printf("\n");

                    for(int i = 1; i<=8; i++) {
                        sleep(1);
                    }
                    PRINTF("Završila obrada prekida razine 2\n");

                    saStoga = popStog().substr(0,1);
                    check = stoi(saStoga);

                    t_p = check;

                    if(check == 0) {
                        PRINTF("Nastavlja se glavni program\n");
                    } else {
                        PRINTF("Nastavlje se prekid %d\n", check);
                    }
                    printajstatus();
                    printf("\n");

                    break;     

            case 3: 
                    printajstatus();
                    printf("\n");

                    t_p = prioritetSignala;
                    PRINTF("Počela obrada prekida razine %d\n", t_p);
                    k_z[t_p-1] = 0;

                    pushStog(naStog); //provjeri
                    printajstatus();
                    printf("\n");

                    for(int i = 1; i<=8; i++) {
                        sleep(1);
                    }
                    PRINTF("Završila obrada prekida razine 3\n");

                    saStoga = popStog().substr(0,1);
                    check = stoi(saStoga);

                    t_p = check;

                    if(check == 0) {
                        PRINTF("Nastavlja se glavni program\n");
                    } else {
                        PRINTF("Nastavlje se prekid %d\n", check);
                    }
                    printajstatus();
                    printf("\n");

                    break;     
            
        }

        promjenaTP = false;


	} else if(prioritetSignala < t_p) {

        PRINTF("SKLOP:Dogodio se prekid razine %d, ne prosljeđuje se još\n", prioritetSignala);
        printajstatus();
        printf("\n");
        return;
    } else return;


    
    for(int i = 2; i >= 0; i--) {
        if(k_z[i] == 1) {
            promjenaTP=true;
            if(i==2) obradi_sig(15);
            if(i==1) obradi_sig(2);
            if(i==0) obradi_sig(10); //za sad funkcionira, dodatno provjeri!!!!!!!!!
        }
    }
    
}

