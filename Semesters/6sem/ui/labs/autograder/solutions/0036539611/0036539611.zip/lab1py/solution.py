import heapq
import argparse
from collections import deque

#Node class, represents a state in the graph
class Node:
    def __init__(self,state):
        self._state = state #state of the node
        self._neighbours = {} #neighbours of the node, key is the state of the neighbour, value is the cost of the edge
        self._parent = None #caller of the node, used for path reconstruction
        self._heur = 0 #heuristic value of the node
        self._cost = 0 #depends on parent caller
    
    #getters and setters
    @property
    def state(self):
        return self._state
    
    @state.setter
    def state(self,state):
        self._state = state 

    @property
    def neighbours(self): 
        return self._neighbours
    
    @neighbours.setter
    def neighbours(self,neighbours):
        self._neighbours = neighbours

    @property
    def parent(self):
        return self._parent

    @parent.setter
    def parent(self,node):
        self._parent = node
    
    @property
    def heur(self):
        return self._heur
    
    @heur.setter
    def heur(self, heur):
        self._heur = heur

    @property
    def cost(self):
        return self._cost
    
    @cost.setter
    def cost(self, cost):
        self._cost = cost

    #overloaded operators
    def __eq__(self, other):
        if isinstance(other, Node):
            return self._state == other._state
        return False

    def __hash__(self):
        return hash(self._state)

    def __lt__(self, other):
        return self._state < other._state

#algorithms for path finding
#some specific data structures used for optimizing the algorithms:
#open - priority queue or deque 
#source: https://docs.python.org/3/library/heapq.html
#source: https://docs.python.org/3/library/collections.html
#open_set - set of states in open, used for faster checking if state is in open

#A* algorithm
#source: lectures and slides
def A_star(start: Node, nodes: dict, goal: list):
    open = [(start._heur, start)]
    open_set = set([start._state]) 
    visited = set()

    while open:
        _ , node = heapq.heappop(open) 
        open_set.remove(node._state)
        visited.add(node._state)

        if node._state in goal:
            return node, len(visited)

        for neighbour in node.neighbours.keys():
            neighbourNode = nodes[neighbour]
            price = node.neighbours[neighbour]
            if (neighbour in visited or neighbour in open_set):
                if neighbourNode._cost > (node._cost + price) or (neighbourNode._cost == 0 and neighbourNode._state != start._state):
                    oldCost = neighbourNode._cost
                    neighbourNode._cost = node._cost + price
                    neighbourNode._parent = node
                    if neighbour in open_set:
                        open.remove((oldCost + neighbourNode._heur, neighbourNode))
                    if neighbour in visited:
                        visited.remove(neighbour)  
                    heapq.heappush(open, (neighbourNode._cost + neighbourNode._heur, neighbourNode))    
            else:   
                neighbourNode._parent = node
                neighbourNode._cost = node._cost + price
                heapq.heappush(open, (node._cost + price + neighbourNode._heur, neighbourNode))
            open_set.add(neighbourNode._state)
    return False, 0

#UCS algorithm
#source: lectures and slides
def UCS(start: Node, nodes: dict, goal: list):
    open = [(0, start)]#tuples?
    #open_set = set([start._state])
    visited = set()

    while open:
        currentCost, node = heapq.heappop(open)
        visited.add(node._state)

        if node._state in goal:
            return node, len(visited)

        for neighbour in node.neighbours.keys():
            neighbourNode = nodes[neighbour]
            price = node.neighbours[neighbour]

            if neighbourNode._state not in visited:
                if neighbourNode._cost > currentCost + price or neighbourNode._cost == 0: #if cost is 0, it means it was not visited yet, else if its in queue check if new cost is lower
                    neighbourNode._parent = node
                    neighbourNode._cost = currentCost + price
                #neighbours.append((neighbourNode, currentCost + price))
                heapq.heappush(open, (currentCost + price, neighbourNode))
                #open_set.add(neighbourNode._state)

    return False, 0

#Breadth first search algorithm
#source: lectures and slides
def BFS(start: Node,nodes: dict,goal: list):
    open = deque([start])
    open_set = set([start._state])
    visited = set()

    while open:
        node = open.popleft()
        open_set.remove(node._state)
        visited.add(node._state)
        if node._state in goal:
            return node, len(visited)
        neighbours = []
        for neighbour in node.neighbours.keys():
            neighbourNode = nodes[neighbour]
            cost = node.neighbours[neighbour]
            if neighbourNode._state not in visited and neighbourNode._state not in open_set:
                neighbourNode._parent = node
                neighbours.append(neighbourNode)
                open_set.add(neighbourNode._state)
                if neighbourNode._cost == 0 or neighbourNode._cost > node._cost + cost:
                    neighbourNode._cost = node._cost + cost
        neighbours.sort(key=lambda x: x) #treba li?
        open.extend(neighbours)


    return False, 0

def setAllCostsToZero(nodes):
    for node in nodes.values():
        node._cost = 0.0

#function to parse the file
def parse_file(file_path):
    nodes = []
    start = None
    goal = None
    with open(file_path, 'r', encoding='utf-8') as state_file:
        for line in state_file:
            if line.startswith('#'):
                continue
            parts = line.strip().split(':')
            state = parts[0]
            if start is None:
                start = Node(state)
                nodes.append(start)
                continue
            if goal is None:
                goal = parts[0].split(' ')
                continue
            node = Node(state)
            if not (node == start):
                nodes.append(node)
            else:
                node = start
            neighbours = parts[1][1:].split(' ')
            if neighbours[0] == '':
                continue
            for neighbour in neighbours:
                neighbour_parts = neighbour.split(',')
                node._neighbours[neighbour_parts[0]] = float(neighbour_parts[1])

    nodes_dict = {node._state: node for node in nodes}

    return start, nodes_dict, goal

#function to parse the heuristic file
def parse_heur(file_path, nodes):
    with open(file_path, 'r', encoding='utf-8') as state_file:
        for line in state_file:
            parts = line.strip().split(':')
            state = parts[0]
            node = nodes[state]
            node._heur = float(parts[1][1:])

#function to print the results
def print_stuff(alg, success, statesVisited, pathLength, cost, path):
    print(success)
    print("[STATES_VISITED]: " + str(statesVisited))
    print("[PATH_LENGTH]: " +  str(pathLength))
    if alg == "BFS":
        print("[TOTAL_COST]: -")
    else:
        print("[TOTAL_COST]: ", cost)
    print("[PATH]: ",path)

def main():
    #parse arguments
    parser = argparse.ArgumentParser()
    parser.add_argument('--alg', type=str, help='Algorithm choice')
    parser.add_argument('--ss', type=str, help='Path to graph description')
    parser.add_argument('--h', type=str, help='Heuristics')
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--check-optimistic', action='store_true', help='Check optimistic')
    group.add_argument('--check-consistent', action='store_true', help='Check consistent')

    args = parser.parse_args()
    alg = args.alg
    file = args.ss
    heur = args.h
    check = None

    if args.check_optimistic:
        check = "check-optimistic"
    elif args.check_consistent:
        check = "check-consistent"

    try:
        start, nodes, goal = parse_file(file)
    except FileNotFoundError:
        print("File not found, exiting")
        return

    if alg == "astar" or check and (check == "check-optimistic" or check == "check-consistent"):
        try:
            parse_heur(heur, nodes)
        except FileNotFoundError:
            print("Heuristic file not found, exiting")
            return
    
    success = "[FOUND_SOLUTION]: "
    path = ""
    pathLength = 1

    if alg == "bfs":
        final, statesVisited = BFS(start, nodes, goal)
        print("# BFS "+ file)
        if final:
            path = final._state + path
            success += "yes"
            #recursively go through the path
            while final:
                #print(final._state)
                final = final._parent
                if final:
                    path = final._state + " => " +  path
                    pathLength += 1
                
        else:
            success += "no"    
            print(success)
            return

        print_stuff(alg, success, statesVisited, pathLength, 0, path)

    if alg == "ucs":
        final, statesVisited = UCS(start, nodes, goal)
        print("# UCS "+ file)
        if final:
            cost = final.cost
            path = final._state + path
            success += "yes"
            
            while final:
                #print(final._state)
                final = final._parent
                if final:
                    path = final._state + " => " +  path
                    pathLength += 1
        else:
            success += "no"
            print(success)
            return
        
        print_stuff(alg, success, statesVisited, pathLength, cost, path)
        return

    if alg == "astar":
        final, statesVisited = A_star(start, nodes, goal)
        print("# A* "+ file)
        if final:
            cost = final.cost
            path = final._state + path
            success += "yes"
            
            while final:
                #print(final._state)
                final = final._parent
                if final:
                    path = final._state + " => " +  path
                    pathLength += 1
        else:
            success += "no"
            print(success)
            return
        
        print_stuff(alg, success, statesVisited, pathLength, cost, path)
        return

    if check == "check-optimistic":
        print("# HEURISTIC-OPTIMISTIC " + heur)
        opt_condition = True
        for node in nodes.values():
            goal_node, _ = UCS(node, nodes, goal) 
                
            if node._heur <= goal_node._cost:
                print("[CONDITION]: [OK] h(" + node._state + ") <= h*: " + str(node._heur) + " <= " + str(goal_node._cost))
            else:
                opt_condition = False
                print("[CONDITION]: [ERR] h(" + node._state + ") <= h*: " + str(node._heur) + " <= " + str(goal_node._cost))
            setAllCostsToZero(nodes) 
        if opt_condition:
            print("[CONCLUSION]: Heuristic is optimistic.")
        else:
            print("[CONCLUSION]: Heuristic is not optimistic.")   
        return    

    if check == "check-consistent":
        print("# HEURISTIC-CONSISTENT " + heur)
        opt_condition = True
        for node in nodes.values():
            for neighbour in node._neighbours:
                neighbourNode = nodes[neighbour]
                cost = node._neighbours[neighbour]
                if node._heur <= (neighbourNode._heur + cost):
                    print("[CONDITION]: [OK] h(" + node._state + ") <= h(" + neighbour   + ") + c: " + str(node._heur) + " <= " + str(neighbourNode._heur) + " + " + str(cost))
                else:
                    opt_condition = False
                    print("[CONDITION]: [ERR] h(" + node._state + ") <= h(" + neighbour   + ") + c: " + str(node._heur) + " <= " + str(neighbourNode._heur) + " + " + str(cost))

        if opt_condition:
            print("[CONCLUSION]: Heuristic is consistent.")
        else:
            print("[CONCLUSION]: Heuristic is not consistent.")
        return    

if __name__ == "__main__":
    main()