#include <iostream>

int main(){
  std::cout << "Hello AI" << std::endl;
  return 0;
}
