from resolution import plResolution
from resolution import negateFinal
import sys

def printResult(clauses,toProveClause,parentDict):
    final = negateFinal(toProveClause)
    #finalString = ' v '.join(final)
    usedStartingClausesString = set()
    usedClausesString = []
    visited = set()
    stack = [("NIL",parentDict["NIL"])]

    while stack:
        parentKey, tuple = stack.pop()
        c1,c2 = tuple
        if c1 in parentDict and c1 not in visited:
            stack.append((c1,parentDict[c1]))
            visited.add(c1)
        if c2 in parentDict and c2 not in visited:
            stack.append((c2,parentDict[c2]))
            visited.add(c2)
        c1string = ' v '.join(c1)
        c2string = ' v '.join(c2)
        resultString = ' v '.join(parentKey)

        if c1 in clauses:# or c1 in final:
            usedStartingClausesString.add(c1string)
        if c2 in clauses:# or c2 in final:
            usedStartingClausesString.add(c2string)    
        if parentKey == "NIL":
            usedClausesString.append(f"{c1string} + {c2string} => {parentKey}")
        else:
            usedClausesString.append(f"{c1string} + {c2string} => {resultString}")
    
    i = 1
    usedClausesString.reverse()

    for string in usedStartingClausesString:
        print(f"{i}. {string}")
        i += 1       
    for string in toProveClause: #!!!![0]
        literal = string[1:] if string[0] == '~' else '~' + string
        print(f"{i}. {literal}")
        i += 1
    print("===============")    
    for string in usedClausesString:
        print(f"{i}. {string}")
        i += 1    

def parse_clause_file(clause_file):
    clauses = set()
    final = set()
    global lastline
    with open(clause_file, 'r', encoding='utf-8') as f:
        lines = f.readlines()
        final = frozenset(lines[-1].strip().lower().split(' v '))
        lastline = lines[-1].strip().lower()

        for i,line in enumerate(lines):
            if line.startswith('#'):
                continue
            if i == (len(lines) - 1):
                continue
            clauses.add(frozenset(line.strip().lower().split(' v ')))

    return clauses, final

def parse_input_file(input_file):
    commands = set()
    with open(input_file, 'r', encoding='utf-8') as f:
        for line in f:
            commands.add(line.strip())
    return commands

def main():
    res_cook = sys.argv[1]
    clause_file = sys.argv[2]
    if res_cook == "cooking":
        input_file = sys.argv[3]
    #res_cook = "resolution"
    #clause_file = '../../../data/lab2/files/new_example_6.txt'
    #input_file = '../../../data/lab2/files/cooking_coffee_input.txt'
    global lastline
    clauses, toProveClause = parse_clause_file(clause_file)

    if res_cook == "resolution":
        result, parentDict = plResolution(clauses,toProveClause)
        toProveClause = list(toProveClause)
 
        result = "true" if result else "unknown"
        if result == "true": #and not (clause_file.endswith("new_example_5.txt") or clause_file.endswith("new_example_6.txt"))
            printResult(clauses,toProveClause,parentDict)
        print("===============")    
        print(f"[CONCLUSION]: {lastline} is {result} ")

    else:
        clauses.add(frozenset(lastline.strip().lower().split(' v ')))
        with open(input_file,'r', encoding='utf-8') as f:
            for line in f:
                command = line.strip()[-1]
                print("User input: ",line.strip())
                if command == '?':
                    toProveClause = frozenset(line.strip()[:-2].lower().split(' v '))
                if command == '+':
                    clauses.add(frozenset(line.strip()[:-2].lower().split(' v ')))  
                    print("added", line.strip()[:-2])
                    continue
                if command == '-':
                    clauses.remove(frozenset(line.strip()[:-2].lower().split(' v '))) 
                    print("removed", line.strip()[:-2])
                    continue  

                result, parentDict = plResolution(clauses,toProveClause)
                toProveClause = list(toProveClause)
                if command == '?':
                    lastline = line.strip().lower()[:-2] 
                result = "true" if result else "unknown"
                if result == "true":
                    printResult(clauses,toProveClause,parentDict)
                print("===============")    
                print(f"[CONCLUSION]: {lastline} is {result} ")  
                print()   

if __name__ == "__main__":
    main()